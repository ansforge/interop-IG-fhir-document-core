# Informations sur la traduction - FR Document Core (FHIR) v0.1.0

## Informations sur la traduction

 
There is no translation page available for the current page, so it has been rendered in the default language 

Ce document contient les informations sur les traductions.

