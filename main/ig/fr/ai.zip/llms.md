# ans.fhir.fr.document-core#0.1.0: FR Document Core (FHIR)(fr)

## Pages

* [Accueil](index.md)
* [Structure générale document](ressourcesFHIR-struc-gen.md)
* [Autres Ressources](autres_ressources.md)
* [Corps d'un document](ressourcesFHIR-corps.md)
* [Entête document](ressourcesFHIR-entete.md)
* [Sécurité](securite.md)
* [Résumé des artefacts](artifacts.md)
* [Informations sur la traduction](translationinfo.md)
* [Téléchargements et usages](downloads.md)

## Resources

### CodeSystems

* [FR CodeSystem Note Type](CodeSystem-fr-cs-note-type.md)

### ValueSets

* [FR ValueSet Participation Type Participant](ValueSet-fr-doc-vs-participation-type-participant.md)
* [FR ValueSet Participation Type Information Recipient](ValueSet-fr-doc-vs-participation-type.md)
* [Fr ValueSet RolePriseCharge](ValueSet-fr-doc-vs-role-prise-charge.md)
* [ValueSet - FR ValueSet Actor Type Document](ValueSet-fr-vs-actor-type-document.md)
* [ValueSet – FR ValueSet Allergy Code Document](ValueSet-fr-vs-allergy-code.md)
* [ValueSet - FR ValueSet Allergy Intolerance Type Document](ValueSet-fr-vs-allergy-intolerance-type-document.md)
* [ValueSet – FR ValueSet Allergy Substance Document](ValueSet-fr-vs-allergy-substance.md)
* [ValueSet - FR ValueSet EDQM Document](ValueSet-fr-vs-edqm-document.md)
* [ValueSet - FR ValueSet EDQM Form Document](ValueSet-fr-vs-edqm-form-document.md)
* [ValueSet – FR ValueSet Type d'évaluation](ValueSet-fr-vs-evaluation-type.md)
* [ValueSet – FR ValueSet Localisation anatomique et voie d'abord](ValueSet-fr-vs-location-body-structure-document.md)
* [ValueSet - FR ValueSet Medication Translation Document](ValueSet-fr-vs-medication-translation-document.md)
* [FR ValueSet Imaging Note Type](ValueSet-fr-vs-note-type.md)
* [ValueSet – FR ValueSet Codes d’actes](ValueSet-fr-vs-procedure-code.md)
* [ValueSet – FR ValueSet Codes vaccins CIS (BDPM)](ValueSet-fr-vs-vaccine-code-cis.md)

### Complex-type Profiles

* [FR Accession Number Identifier Document](StructureDefinition-fr-accession-number-identifier-document.md)
* [FR Human Name Document](StructureDefinition-fr-human-name-document.md)
* [FR Study Instance Uid Identifier Document](StructureDefinition-fr-study-instance-uid-identifier-document.md)

### Resource Profiles

* [Consent - FR Advance directive Document](StructureDefinition-fr-advance-directive-document.md)
* [AdverseEvent - FR adverse event Document](StructureDefinition-fr-adverse-event-document.md)
* [AllergyIntolerance - FR Allergy and intolerance Document](StructureDefinition-fr-allergy-intolerance-document.md)
* [BodyStructure - FR Body Structure Document](StructureDefinition-fr-body-structure-document.md)
* [FR Bundle Document](StructureDefinition-fr-bundle-document.md)
* [CarePlan - FR Care Plan Document](StructureDefinition-fr-care-plan-document.md)
* [FR Composition Document](StructureDefinition-fr-composition-document.md)
* [Condition - FR Condition Document](StructureDefinition-fr-condition-document.md)
* [FR Device Document](StructureDefinition-fr-device-auteur-document.md)
* [DeviceRequest - FR Device request Document](StructureDefinition-fr-device-request-document.md)
* [DeviceUseStatement - FR Device Use Statement Document](StructureDefinition-fr-device-use-statement-document.md)
* [DiagnosticReport - FR Diagnostic Report BIO chapter Document](StructureDefinition-fr-diagnostic-report-bio-chapter-document.md)
* [DiagnosticReport - FR Diagnostic Report Document](StructureDefinition-fr-diagnostic-report-document.md)
* [DiagnosticReport - FR Diagnostic Report Imaging Document](StructureDefinition-fr-diagnostic-report-imaging-document.md)
* [DocumentReference - FR Document reference Document](StructureDefinition-fr-document-reference-document.md)
* [FR Encounter Care Document](StructureDefinition-fr-encounter-care-document.md)
* [Encounter - FR Encounter Document](StructureDefinition-fr-encounter-document.md)
* [Endpoint - FR Endpoint Wado Document](StructureDefinition-fr-endpoint-wado-document.md)
* [FamilyMemberHistory - FR Family Member History Document](StructureDefinition-fr-family-member-history-document.md)
* [ImagingStudy - FR Imaging study Document](StructureDefinition-fr-imaging-study-document.md)
* [Immunization - FR Immunization Document](StructureDefinition-fr-immunization-document.md)
* [ImmunizationRecommendation - FR Immunization Recommendation Document](StructureDefinition-fr-immunization-recommendation-document.md)
* [FR Location Document](StructureDefinition-fr-location-document.md)
* [Media - FR Media Document](StructureDefinition-fr-media-document.md)
* [MedicationAdministration - FR Medication Administration Document](StructureDefinition-fr-medication-administration-document.md)
* [MedicationDispense - FR Medication Dispense Document](StructureDefinition-fr-medication-dispense-document.md)
* [Medication - FR Medication Document](StructureDefinition-fr-medication-document.md)
* [MedicationRequest - FR Medication Request Document](StructureDefinition-fr-medication-request-document.md)
* [MedicationStatement - FR Medication Statement Document](StructureDefinition-fr-medication-statement-document.md)
* [Observation - FR Observation ALD Document](StructureDefinition-fr-observation-ald-document.md)
* [Observation - FR Observation Assessment Document](StructureDefinition-fr-observation-assessment-document.md)
* [Observation - FR Observation Contra Indications Document](StructureDefinition-fr-observation-contra-indications-document.md)
* [Observation - FR Observation Laboratory Report Results Document](StructureDefinition-fr-observation-laboratory-report-results-document.md)
* [Observation - FR Observation Microorganism Detection Document](StructureDefinition-fr-observation-microorganism-detection-document.md)
* [Observation - FR Observation Multiresistant Microorganisms Identification Document](StructureDefinition-fr-observation-multiresistant-microorganism-document.md)
* [Observation - FR Observation Pain Score Document](StructureDefinition-fr-observation-pain-score-document.md)
* [Observation - FR Observation Pregnancy Document](StructureDefinition-fr-observation-pregnancy-document.md)
* [Observation - FR Observation Pregnancy History Document](StructureDefinition-fr-observation-pregnancy-history-document.md)
* [Observation - FR Observation Prevention Document](StructureDefinition-fr-observation-prevention-document.md)
* [Observation - FR Observation Radiation Exposure Document](StructureDefinition-fr-observation-radiation-exposure-document.md)
* [Observation - FR Observation Result Document](StructureDefinition-fr-observation-result-document.md)
* [Observation - FR Observation Social History Document](StructureDefinition-fr-observation-social-history-document.md)
* [Observation - FR Observation Vital Signs Document](StructureDefinition-fr-observation-vital-signs-document.md)
* [Observation - FR Observation Vital Signs Panel Document](StructureDefinition-fr-observation-vital-signs-panel-document.md)
* [Observation - FR Observation Work Related Accident Document](StructureDefinition-fr-observation-work-related-accident-document.md)
* [FR Organization Document](StructureDefinition-fr-organization-document.md)
* [FR Patient Document](StructureDefinition-fr-patient-document.md)
* [FR Patient INS Document](StructureDefinition-fr-patient-ins-document.md)
* [FR Practitioner Document](StructureDefinition-fr-practitioner-document.md)
* [FR PractitionerRole Document](StructureDefinition-fr-practitionerRole-document.md)
* [Procedure - FR Procedure Document](StructureDefinition-fr-procedure-document.md)
* [Procedure - FR Procedure Imaging Document](StructureDefinition-fr-procedure-imaging-document.md)
* [FR RelatedPerson Document](StructureDefinition-fr-related-person-document.md)
* [ServiceRequest - FR Service Request Document](StructureDefinition-fr-service-request-document.md)
* [ServiceRequest - FR Service Request Imaging Document](StructureDefinition-fr-service-request-imaging-document.md)
* [Specimen - FR Specimen Document](StructureDefinition-fr-specimen-document.md)
* [Task - FR Task Patient Transport Document](StructureDefinition-fr-task-patient-transport-document.md)

### Extensions

* [FR Actor Extension](StructureDefinition-fr-actor-extension.md)
* [FR Author Time Extension](StructureDefinition-fr-author-time-extension.md)
* [FR Comparison Studies Extension](StructureDefinition-fr-comparison-studies-extension.md)
* [FR Family Member History Body Site Extension](StructureDefinition-fr-family-member-history-body-site-extension.md)
* [FR Imaging Procedure Extension](StructureDefinition-fr-imaging-procedure-extension.md)
* [FR Immunization Type Extension](StructureDefinition-fr-immunization-type-extension.md)
* [FR Interpretation Extension](StructureDefinition-fr-interpretation-extension.md)
* [FR Medication Administration Sequence Extension](StructureDefinition-fr-medication-administration-sequence-extension.md)
* [FR Method Extension](StructureDefinition-fr-method-extension.md)
* [FR Not Covered Extension](StructureDefinition-fr-not-covered-extension.md)
* [FR Note Type Extension](StructureDefinition-fr-note-type-extension.md)
* [FR Number of Frames Extension](StructureDefinition-fr-number-of-frames-extension.md)
* [FR Patient History Extension](StructureDefinition-fr-patient-history-extension.md)
* [FR Performer Event Extension](StructureDefinition-fr-performer-event-extension.md)
* [FR Procedure Difficulty Extension](StructureDefinition-fr-procedure-difficulty-extension.md)
* [FR Procedure Priority Extension](StructureDefinition-fr-procedure-priority-extension.md)
* [FR Status Reason Extension](StructureDefinition-fr-status-reason-extension.md)

### ImplementationGuides

* [FR Document Core (FHIR)](ImplementationGuide-ans.fhir.fr.document-core.md)

### Examples

* [example-allergy-intolerance-data-absent-reason (AllergyIntolerance)](AllergyIntolerance-example-allergy-intolerance-data-absent-reason.md)
* [ba499de3-aeae-43c3-82cb-0ba2718cfa41 (Patient)](Patient-ba499de3-aeae-43c3-82cb-0ba2718cfa41.md)
* [ba499de3-aeae-43c3-82cb-0ba2718cfa55 (Patient)](Patient-ba499de3-aeae-43c3-82cb-0ba2718cfa55.md)
* [example-procedure-data-absent-reason (Procedure)](Procedure-example-procedure-data-absent-reason.md)
